#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double alea( double a, double b);
int alea_integer(int a, int b);
                                  



