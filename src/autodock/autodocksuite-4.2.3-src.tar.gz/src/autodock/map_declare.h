/*
 $Id: map_declare.h,v 1.1 2008/10/15 23:59:14 rhuey Exp $
*/

MapType map[MAX_GRID_PTS][MAX_GRID_PTS][MAX_GRID_PTS][MAX_MAPS],    //  intermolecular interaction energies

